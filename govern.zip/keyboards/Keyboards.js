module.exports = {
  setKeyboard: new Array(
    new Array({
      text: "Raqamni yuborish",
      request_contact: true,
    })
  ),
  setMainKey: new Array(
    new Array(
      {
        text: "Service",
      },
      {
        text: "Meeting",
      }
    )
  ),
};
